package com.example.crud;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {
    EditText email, password;
    Button signin;
    TextView forgotPass, deleteAccount;
    DatabaseHelper DB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        DB = new DatabaseHelper(getContext());

        email = view.findViewById(R.id.login_email);
        password = view.findViewById(R.id.login_password);
        signin = view.findViewById(R.id.btn_signin);
        forgotPass = view.findViewById(R.id.tv_forgot);
        deleteAccount = view.findViewById(R.id.tv_delete);

        signin.setOnClickListener(v -> {
            if(DB.checkUserPassword(email.getText().toString(), password.getText().toString()))
                Toast.makeText(getContext(), "Login Success!", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(getContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
        });

        // Navigate to Screen 3 (Update/Delete)
        View.OnClickListener goToManage = v -> getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new ManageAccountFragment()).commit();

        forgotPass.setOnClickListener(goToManage);
        deleteAccount.setOnClickListener(goToManage);

        return view;
    }
}