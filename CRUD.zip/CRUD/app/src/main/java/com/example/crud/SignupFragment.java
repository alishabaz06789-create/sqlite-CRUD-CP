package com.example.crud;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;

public class SignupFragment extends Fragment {
    EditText username, email, password, dob;
    Button signup;
    DatabaseHelper DB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signup, container, false);

        DB = new DatabaseHelper(getContext());
        username = view.findViewById(R.id.et_username);
        email = view.findViewById(R.id.et_email);
        password = view.findViewById(R.id.et_password);
        dob = view.findViewById(R.id.et_dob);
        signup = view.findViewById(R.id.btn_signup);
        // Add this inside onCreateView
        TextView backToLogin = view.findViewById(R.id.tv_back_to_login);
        backToLogin.setOnClickListener(v -> {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new LoginFragment())
                    .commit();
        });
        signup.setOnClickListener(v -> {
            String user = username.getText().toString();
            String mail = email.getText().toString();
            String pass = password.getText().toString();
            String date = dob.getText().toString();

            if(user.isEmpty() || mail.isEmpty() || pass.isEmpty())
                Toast.makeText(getContext(), "Fill all fields", Toast.LENGTH_SHORT).show();
            else {
                if(DB.insertData(user, mail, pass, date)) {
                    Toast.makeText(getContext(), "Registered!", Toast.LENGTH_SHORT).show();
                    // Move to Login Screen
                    getParentFragmentManager().beginTransaction().replace(R.id.fragment_container, new LoginFragment()).commit();
                }
            }
        });
        return view;
    }
}