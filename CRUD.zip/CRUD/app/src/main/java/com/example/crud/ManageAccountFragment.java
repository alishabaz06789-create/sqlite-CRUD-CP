package com.example.crud;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;

public class ManageAccountFragment extends Fragment {
    EditText email, newPassword;
    Button btnUpdate, btnDelete;
    DatabaseHelper DB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_manage, container, false);
        DB = new DatabaseHelper(getContext());
        // Add this inside onCreateView
        Button btnBack = view.findViewById(R.id.btn_back_manage);
        btnBack.setOnClickListener(v -> {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new LoginFragment())
                    .commit();
        });
        email = view.findViewById(R.id.manage_email);
        newPassword = view.findViewById(R.id.new_password);
        btnUpdate = view.findViewById(R.id.btn_update_pass);
        btnDelete = view.findViewById(R.id.btn_delete_acc);

        btnUpdate.setOnClickListener(v -> {
            if(DB.updatePassword(email.getText().toString(), newPassword.getText().toString()))
                Toast.makeText(getContext(), "Password Updated!", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(getContext(), "Update Failed", Toast.LENGTH_SHORT).show();
        });

        btnDelete.setOnClickListener(v -> {
            if(DB.deleteAccount(email.getText().toString())) {
                Toast.makeText(getContext(), "Account Deleted!", Toast.LENGTH_SHORT).show();
                getParentFragmentManager().beginTransaction().replace(R.id.fragment_container, new SignupFragment()).commit();
            } else
                Toast.makeText(getContext(), "Delete Failed", Toast.LENGTH_SHORT).show();
        });

        return view;
    }
}